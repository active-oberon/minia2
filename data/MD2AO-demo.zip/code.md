# Код і кнопка Copy

[Повернутися на головну](index.md)

Угорі кожного блоку коду є смужка з назвою мови та кнопкою **Copy**. Після кліку код опиняється в буфері обміну, а підпис кнопки на мить змінюється на «Copied».

## Active Oberon із підсвічуванням

```oberon
MODULE Demo; (* коментар (* із вкладеним коментарем *) все ще коментар *)

IMPORT KernelLog, Strings;

CONST
	Max = 100; Mask = 0FFH; Pi = 3.14159E+0; Ch = 0DX;

TYPE
	Point* = RECORD x*, y*: SIGNED32 END;

	Counter* = OBJECT
	VAR n: SIZE;

		PROCEDURE &Init*;
		BEGIN n := 0 END Init;

		PROCEDURE Next*(): SIZE;
		BEGIN {EXCLUSIVE} INC(n); RETURN n END Next;
	END Counter;

PROCEDURE Hello*(CONST name: ARRAY OF CHAR);
VAR s: ARRAY 64 OF CHAR; i: SIGNED32;
BEGIN
	COPY("Hello, ", s); Strings.Append(s, name);   (* коментар, що
	займає два рядки *)
	FOR i := 1 TO Max DIV 10 DO
		KernelLog.Int(i, 0); KernelLog.String(' - Привіт, світе'); KernelLog.Ln
	END;
	IF (Max # 0) & ~FALSE THEN HALT(99) END
END Hello;

END Demo.
```

Ті самі правила діють для тегів `ao`, `activeoberon` та `a2`. Кольори й шрифти задаються у файлі стилів.

## Інші мови та блоки без мови

Блок з іншою мовою не розфарбовується, але копіюється так само:

```text
Compiler.Compile MDTree.Mod MDView.Mod ~
MDView.ShowArchive MD2AO-demo.zip ~
```

Блок без мови теж має смужку з кнопкою:

```
VAR x: INTEGER;   (* цей блок не підсвічується *)
```
