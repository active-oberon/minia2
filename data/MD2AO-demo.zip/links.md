# Посилання та якорі

[Повернутися на головну](index.md)

## Внутрішні посилання

Якорем стає кожен заголовок. Його назва утворюється з тексту заголовка малими літерами з дефісами замість пробілів, кирилиця зберігається. Перейти до [розділу з довгим текстом](#довгий-розділ-для-прокрутки), а потім повернутися [нагору](#посилання-та-якорі).

## Посилання на інші сторінки

- [Таблиці з вирівнюванням](tables.md#вирівнювання-стовпців): сторінка відкривається й прокручується до розділу
- [Широке зображення](images.md#широке-зображення)
- [Код Oberon](code.md#active-oberon-із-підсвічуванням)
- [Просто сторінка без якоря](text.md)

Після кількох переходів скористайтеся кнопками **Back** і **Forward** на панелі зверху. Сторінка відкривається там, де ви її залишили.

## Зовнішні посилання

Посилання зі схемою, такі як <https://example.org> чи <mailto:name@example.org>, переглядач передає обробникові; якщо обробника немає, запис про це потрапляє в журнал системи.

## Довгий розділ для прокрутки

Цей розділ потрібен лише для того, щоб сторінка була довшою за вікно.

Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.

Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.

Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt.

Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem.

Назад до [початку сторінки](#посилання-та-якорі).
